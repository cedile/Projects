import math
import tkinter as tk
from tkinter import messagebox

# Funktion zur Berechnung des Dreiecks
def calculate_triangle():
    try:
        # Eingaben lesen und konvertieren (leere Felder als None setzen)
        a = float(entry_a.get()) if entry_a.get() else None
        b = float(entry_b.get()) if entry_b.get() else None
        c = float(entry_c.get()) if entry_c.get() else None
        angle_A = float(entry_angle_A.get()) if entry_angle_A.get() else None
        angle_B = float(entry_angle_B.get()) if entry_angle_B.get() else None
        angle_C = float(entry_angle_C.get()) if entry_angle_C.get() else None
        tan_value = float(entry_tan.get()) if entry_tan.get() else None

        # Wenn das Dreieck rechtwinklig ist (gamma = 90°), verwende die rechtwinklige Trigonometrie
        if angle_C == 90 or (angle_A == 90 or angle_B == 90):
            if angle_C == 90:
                angle_A, angle_B = 90 - angle_B, 90 - angle_A
            elif angle_A == 90:
                angle_C, angle_B = 90 - angle_C, 90 - angle_B
            elif angle_B == 90:
                angle_C, angle_A = 90 - angle_C, 90 - angle_A

            # Berechnungen für rechtwinklige Dreiecke
            if c and angle_A:  # Hypotenuse und Winkel A
                a = c * math.sin(math.radians(angle_A))
                b = c * math.cos(math.radians(angle_A))
            elif a and b:  # a und b gegeben
                c = math.sqrt(a**2 + b**2)
                angle_A = math.degrees(math.atan(a / b))
            elif tan_value:
                angle_A = math.degrees(math.atan(tan_value))
                angle_B = 90 - angle_A
                b = a / tan_value if a else b * tan_value if b else c
            # Ergebnisanzeige für rechtwinkliges Dreieck
            angle_C = 90

        else:
            # Allgemeines Dreieck, verwende Sinus- und Kosinussatz
            if a and b and angle_C:  # Kosinussatz bei gegebener Seite a, b und Winkel C
                c = math.sqrt(a**2 + b**2 - 2 * a * b * math.cos(math.radians(angle_C)))
                angle_A = math.degrees(math.asin((a * math.sin(math.radians(angle_C))) / c))
                angle_B = 180 - angle_A - angle_C
            elif a and angle_A and angle_B:  # Sinussatz bei gegebenem Winkelpaar und Seite
                angle_C = 180 - angle_A - angle_B
                b = a * math.sin(math.radians(angle_B)) / math.sin(math.radians(angle_A))
                c = a * math.sin(math.radians(angle_C)) / math.sin(math.radians(angle_A))
            elif a and b and c:  # Kosinussatz bei allen drei Seiten gegeben
                angle_A = math.degrees(math.acos((b**2 + c**2 - a**2) / (2 * b * c)))
                angle_B = math.degrees(math.acos((a**2 + c**2 - b**2) / (2 * a * c)))
                angle_C = 180 - angle_A - angle_B

        # Ergebnisse anzeigen
        result_label.config(text=f"a = {a:.2f} cm, b = {b:.2f} cm, c = {c:.2f} cm\n"
                                 f"Winkel A = {angle_A:.2f}°, Winkel B = {angle_B:.2f}°, Winkel C = {angle_C:.2f}°")

    except ValueError:
        messagebox.showerror("Fehler", "Bitte gültige Zahlen eingeben.")
    except (TypeError, ZeroDivisionError):
        messagebox.showerror("Fehler", "Ungültige Eingabe oder unmögliche Werte.")

# Funktion zum Löschen aller Eingaben und Ergebnisse
def clear_inputs():
    entry_a.delete(0, tk.END)
    entry_b.delete(0, tk.END)
    entry_c.delete(0, tk.END)
    entry_angle_A.delete(0, tk.END)
    entry_angle_B.delete(0, tk.END)
    entry_angle_C.delete(0, tk.END)
    entry_tan.delete(0, tk.END)
    result_label.config(text="Ergebnis wird hier angezeigt.")

# Hauptfenster erstellen
window = tk.Tk()
window.title("Erweiterter Dreiecksrechner")

# Eingabefelder für Seiten und Winkel
tk.Label(window, text="Seite a:").grid(row=0, column=0)
entry_a = tk.Entry(window)
entry_a.grid(row=0, column=1)

tk.Label(window, text="Seite b:").grid(row=1, column=0)
entry_b = tk.Entry(window)
entry_b.grid(row=1, column=1)

tk.Label(window, text="Seite c:").grid(row=2, column=0)
entry_c = tk.Entry(window)
entry_c.grid(row=2, column=1)

tk.Label(window, text="Winkel A (°):").grid(row=3, column=0)
entry_angle_A = tk.Entry(window)
entry_angle_A.grid(row=3, column=1)

tk.Label(window, text="Winkel B (°):").grid(row=4, column=0)
entry_angle_B = tk.Entry(window)
entry_angle_B.grid(row=4, column=1)

tk.Label(window, text="Winkel C (°):").grid(row=5, column=0)
entry_angle_C = tk.Entry(window)
entry_angle_C.grid(row=5, column=1)

tk.Label(window, text="Tangenswert (optional):").grid(row=6, column=0)
entry_tan = tk.Entry(window)
entry_tan.grid(row=6, column=1)

# Berechnen-Schaltfläche
calculate_button = tk.Button(window, text="Berechnen", command=calculate_triangle)
calculate_button.grid(row=7, column=0, columnspan=2)

# Clear-Schaltfläche
clear_button = tk.Button(window, text="Clear", command=clear_inputs)
clear_button.grid(row=8, column=0, columnspan=2)

# Ergebnisanzeige
result_label = tk.Label(window, text="Ergebnis wird hier angezeigt.")
result_label.grid(row=9, column=0, columnspan=2)

# Hauptfenster ausführen
window.mainloop()
