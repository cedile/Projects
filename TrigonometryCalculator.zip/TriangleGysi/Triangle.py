import math
import tkinter as tk

def berechne_dreieck():
    # Lösche vorherige Ergebnisse und Fehlermeldungen
    label_ergebnis.config(text="")
    try:
        # Eingaben abrufen und konvertieren
        a_input = entry_a.get()
        b_input = entry_b.get()
        c_input = entry_c.get()
        A_input = entry_A.get()
        B_input = entry_B.get()

        def parse_input(value):
            return float(value) if value.strip() != '' else None

        a = parse_input(a_input)
        b = parse_input(b_input)
        c = parse_input(c_input)
        A = parse_input(A_input)
        B = parse_input(B_input)
        C = 90  # Rechtwinkliges Dreieck

        # Konvertiere Winkel in Radiant
        A_rad = math.radians(A) if A is not None else None
        B_rad = math.radians(B) if B is not None else None
        C_rad = math.radians(C)

        # Fall 1: Kathete b und Winkel A gegeben
        if b is not None and A is not None:
            a = b * math.tan(A_rad)
            c = b / math.cos(A_rad)
            B = 90 - A

        # Fall 2: Kathete a und Winkel A gegeben
        elif a is not None and A is not None:
            b = a / math.tan(A_rad)
            c = a / math.sin(A_rad)
            B = 90 - A

        # Fall 3: Kathete b und Winkel B gegeben
        elif b is not None and B is not None:
            a = b * math.tan(B_rad)
            c = b / math.cos(B_rad)
            A = 90 - B

        # Fall 4: Kathete a und Winkel B gegeben
        elif a is not None and B is not None:
            b = a / math.tan(B_rad)
            c = a / math.sin(B_rad)
            A = 90 - B

        # Fall 5: Hypotenuse c und Winkel A gegeben
        elif c is not None and A is not None:
            a = c * math.sin(A_rad)
            b = c * math.cos(A_rad)
            B = 90 - A

        # Fall 6: Hypotenuse c und Winkel B gegeben
        elif c is not None and B is not None:
            b = c * math.sin(B_rad)
            a = c * math.cos(B_rad)
            A = 90 - B

        # Fall 7: Zwei Katheten gegeben (a und b)
        elif a is not None and b is not None:
            c = math.sqrt(a**2 + b**2)
            A_rad = math.atan(a / b)
            B_rad = math.atan(b / a)
            A = math.degrees(A_rad)
            B = math.degrees(B_rad)

        # Fall 8: Eine Kathete (a oder b) und Hypotenuse c gegeben
        elif a is not None and c is not None:
            b = math.sqrt(c**2 - a**2)
            A_rad = math.asin(a / c)
            B = 90 - math.degrees(A_rad)
            A = math.degrees(A_rad)

        elif b is not None and c is not None:
            a = math.sqrt(c**2 - b**2)
            B_rad = math.asin(b / c)
            A = 90 - math.degrees(B_rad)
            B = math.degrees(B_rad)

        # Fall 9: Alle Seiten gegeben
        elif a is not None and b is not None and c is not None:
            if abs(c**2 - (a**2 + b**2)) > 1e-6:
                label_ergebnis.config(text="Das Dreieck ist nicht rechtwinklig.", fg="red")
                return
            A_rad = math.asin(a / c)
            B_rad = math.acos(a / c)
            A = math.degrees(A_rad)
            B = math.degrees(B_rad)

        # Ergebnisse anzeigen
        entry_a.delete(0, tk.END)
        entry_a.insert(0, f"{a:.2f}" if a is not None else "")
        entry_b.delete(0, tk.END)
        entry_b.insert(0, f"{b:.2f}" if b is not None else "")
        entry_c.delete(0, tk.END)
        entry_c.insert(0, f"{c:.2f}" if c is not None else "")
        entry_A.delete(0, tk.END)
        entry_A.insert(0, f"{A:.2f}" if A is not None else "")
        entry_B.delete(0, tk.END)
        entry_B.insert(0, f"{B:.2f}" if B is not None else "")
        label_ergebnis.config(text="Dreieck erfolgreich berechnet.", fg="green")

    except ValueError:
        label_ergebnis.config(text="Ungültige Eingabe. Bitte nur numerische Werte eingeben.", fg="red")

def clear_fields():
    entry_a.delete(0, tk.END)
    entry_b.delete(0, tk.END)
    entry_c.delete(0, tk.END)
    entry_A.delete(0, tk.END)
    entry_B.delete(0, tk.END)
    label_ergebnis.config(text="")

# GUI erstellen
root = tk.Tk()
root.title("Rechtwinkliges Dreieck Berechnung")

# Eingabefelder und Labels
row = 0

label_a = tk.Label(root, text="Seite a (Kathete):")
label_a.grid(row=row, column=0, padx=5, pady=5, sticky='e')
entry_a = tk.Entry(root)
entry_a.grid(row=row, column=1, padx=5, pady=5)
row += 1

label_b = tk.Label(root, text="Seite b (Kathete):")
label_b.grid(row=row, column=0, padx=5, pady=5, sticky='e')
entry_b = tk.Entry(root)
entry_b.grid(row=row, column=1, padx=5, pady=5)
row += 1

label_c = tk.Label(root, text="Seite c (Hypotenuse):")
label_c.grid(row=row, column=0, padx=5, pady=5, sticky='e')
entry_c = tk.Entry(root)
entry_c.grid(row=row, column=1, padx=5, pady=5)
row += 1

label_A = tk.Label(root, text="Winkel A (°):")
label_A.grid(row=row, column=0, padx=5, pady=5, sticky='e')
entry_A = tk.Entry(root)
entry_A.grid(row=row, column=1, padx=5, pady=5)
row += 1

label_B = tk.Label(root, text="Winkel B (°):")
label_B.grid(row=row, column=0, padx=5, pady=5, sticky='e')
entry_B = tk.Entry(root)
entry_B.grid(row=row, column=1, padx=5, pady=5)
row += 1

# Buttons
button_frame = tk.Frame(root)
button_frame.grid(row=row, column=0, columnspan=2, pady=10)

button_berechnen = tk.Button(button_frame, text="Berechnen", command=berechne_dreieck)
button_berechnen.pack(side=tk.LEFT, padx=5)

button_clear = tk.Button(button_frame, text="Zurücksetzen", command=clear_fields)
button_clear.pack(side=tk.LEFT, padx=5)

row += 1

# Ergebnislabel
label_ergebnis = tk.Label(root, text="", fg="green", justify="left")
label_ergebnis.grid(row=row, column=0, columnspan=2)

# Hauptschleife starten
root.mainloop()

