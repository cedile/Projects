package ch.bbw.zork;

/**
 * Represents an enemy in the game.
 */
public class Enemy {
    private String name;          // The enemy's name
    private String description;    // A description of the enemy
    private int health;            // Health points of the enemy

    /**
     * Creates a new enemy.
     *
     * @param name        The name of the enemy.
     * @param description A description of the enemy.
     * @param health      The enemy's initial health points.
     */
    public Enemy(String name, String description, int health) {
        this.name = name;                  // Set the enemy's name
        this.description = description;    // Set the enemy's description
        this.health = health;              // Set the enemy's starting health points
    }

    /**
     * Returns the enemy's name.
     *
     * @return The enemy's name.
     */
    public String getName() {
        return name;                       // Return the enemy's name
    }

    /**
     * Returns the enemy's description.
     *
     * @return The description.
     */
    public String getDescription() {
        return description;                // Return the description of the enemy
    }

    /**
     * Reduces the enemy's health by a specified amount.
     *
     * @param amount The amount of damage taken.
     */
    public void takeDamage(int amount) {
        health -= amount;                  // Decrease health by the specified damage amount
    }

    /**
     * Checks if the enemy is defeated.
     *
     * @return True if the enemy's health is zero or less.
     */
    public boolean isDefeated() {
        return health <= 0;                // Return true if health is zero or less, indicating defeat
    }
}
