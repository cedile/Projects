package ch.bbw.zork;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The Player class represents the player in the game "Zork".
 * It manages the player's state, including inventory, health, and hunger.
 */
public class Player {
    private String name;             // The player's name
    private int health;              // Player's current health level (0 to 100)
    private int hunger;              // Player's current hunger level (0 to 100)
    private int maxWeight;           // Maximum weight the player can carry
    private List<Item> inventory;    // List of items the player carries

    /**
     * Constructor for the player.
     *
     * @param name The player's name.
     */
    public Player(String name) {
        this.name = name;            // Set the player's name
        this.health = 100;           // Starting health
        this.hunger = 100;           // Starting hunger
        this.maxWeight = 30;         // Maximum carrying weight in kg
        this.inventory = new ArrayList<>(); // Initialize inventory as an empty list
    }

    /**
     * Returns the player's name.
     *
     * @return The name.
     */
    public String getName() {
        return name;                 // Return the player's name
    }

    /**
     * Adds an item to the player's inventory.
     *
     * @param item The item to add.
     */
    public void addItem(Item item) {
        inventory.add(item);         // Add the item to the player's inventory list
    }

    /**
     * Removes an item from the player's inventory.
     *
     * @param itemName The name of the item to remove.
     * @return True if the item was removed, false otherwise.
     */
    public boolean removeItem(String itemName) {
        Iterator<Item> iterator = inventory.iterator(); // Use iterator to safely remove items
        while (iterator.hasNext()) {
            Item item = iterator.next();
            if (item.getName().equalsIgnoreCase(itemName)) {
                iterator.remove();    // Remove the item if the names match
                return true;          // Return true to indicate successful removal
            }
        }
        return false;                 // Return false if the item wasn't found
    }

    /**
     * Checks if the player has a specific item.
     *
     * @param itemName The name of the item.
     * @return True if the player has the item, false otherwise.
     */
    public boolean hasItem(String itemName) {
        for (Item item : inventory) { // Loop through all items in the inventory
            if (item.getName().equalsIgnoreCase(itemName)) {
                return true;          // Return true if item is found
            }
        }
        return false;                 // Return false if item isn't in inventory
    }

    /**
     * Returns the player's inventory.
     *
     * @return A list of items.
     */
    public List<Item> getInventory() {
        return inventory;             // Return the inventory list
    }

    /**
     * Returns the current total weight of carried items.
     *
     * @return The current weight.
     */
    public int getCurrentWeight() {
        int totalWeight = 0;          // Start with zero total weight
        for (Item item : inventory) { // Sum up the weight of each item in inventory
            totalWeight += item.getWeight();
        }
        return totalWeight;           // Return the calculated total weight
    }

    /**
     * Returns the player's maximum carrying weight.
     *
     * @return The maximum weight.
     */
    public int getMaxWeight() {
        return maxWeight;             // Return the maximum weight the player can carry
    }

    /**
     * Reduces the player's health by a specified amount.
     *
     * @param amount The amount to reduce health by.
     */
    public void takeDamage(int amount) {
        health -= amount;             // Reduce health by the specified amount
        if (health < 0) {             // Ensure health doesn't go below 0
            health = 0;
        }
    }

    /**
     * Increases the player's health by a specified amount.
     *
     * @param amount The amount to increase health by.
     */
    public void heal(int amount) {
        health += amount;             // Increase health by the specified amount
        if (health > 100) {           // Ensure health doesn't exceed the maximum of 100
            health = 100;
        }
    }

    /**
     * Checks if the player is alive.
     *
     * @return True if health is greater than 0, false otherwise.
     */
    public boolean isAlive() {
        return health > 0;            // Return true if health is above 0
    }

    /**
     * Returns the player's current health.
     *
     * @return The health.
     */
    public int getHealth() {
        return health;                // Return the player's current health level
    }

    /**
     * Decreases the player's hunger by a specified amount.
     *
     * @param amount The amount to decrease hunger by.
     */
    public void decreaseHunger(int amount) {
        hunger -= amount;             // Decrease hunger by the specified amount
        if (hunger < 0) {             // Ensure hunger doesn't go below 0
            hunger = 0;
        }
    }

    /**
     * Increases the player's hunger by a specified amount.
     *
     * @param amount The amount to increase hunger by.
     */
    public void eat(int amount) {
        hunger += amount;             // Increase hunger by the specified amount
        if (hunger > 100) {           // Ensure hunger doesn't exceed the maximum of 100
            hunger = 100;
        }
    }

    /**
     * Checks if the player is hungry.
     *
     * @return True if hunger is zero or less.
     */
    public boolean isHungry() {
        return hunger <= 0;           // Return true if hunger level is zero or less
    }

    /**
     * Returns the player's current hunger level.
     *
     * @return The hunger level.
     */
    public int getHunger() {
        return hunger;                // Return the player's current hunger level
    }

    /**
     * Retrieves an item from the inventory by name.
     *
     * @param itemName The name of the item.
     * @return The item if found, null otherwise.
     */
    public Item getItem(String itemName) {
        for (Item item : inventory) { // Loop through items to find one matching itemName
            if (item.getName().equalsIgnoreCase(itemName)) {
                return item;          // Return the item if found
            }
        }
        return null;                  // Return null if item wasn't found
    }

    /**
     * Displays the player's status, including health, hunger, and inventory.
     */
    public void showStatus() {
        System.out.println("Health: " + health + "/100"); // Display health status
        System.out.println("Hunger: " + hunger + "/100"); // Display hunger status
        System.out.println("Weight: " + getCurrentWeight() + "/" + maxWeight + "kg"); // Show weight carried vs. max capacity
        System.out.println("Inventory:");
        if (inventory.isEmpty()) {    // If inventory is empty, display "Nothing"
            System.out.println("- Nothing");
        } else {
            for (Item item : inventory) { // Display each item in inventory with name and weight
                System.out.println("- " + item.getName() + " (" + item.getWeight() + "kg)");
            }
        }
    }
}
