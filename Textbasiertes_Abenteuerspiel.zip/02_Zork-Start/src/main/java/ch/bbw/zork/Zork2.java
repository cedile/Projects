package ch.bbw.zork;

/**
 * The main class of the game "Zork".
 * Starts the game by creating a new instance of Game and calling the play() method.
 */
public class Zork2 {
	public static void main(String[] args) {
		Game game = new Game();
		game.play();
	}
}
