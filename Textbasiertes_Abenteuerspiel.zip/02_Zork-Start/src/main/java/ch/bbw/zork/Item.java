package ch.bbw.zork;

/**
 * Represents an item in the game.
 */
public class Item {
    private String name;           // The name of the item
    private String description;     // A brief description of the item
    private int weight;             // The weight of the item in game units
    private Riddle riddle;          // A riddle associated with the item, can be null if no riddle is present

    /**
     * Creates a new item.
     *
     * @param name        The item's name.
     * @param description The item's description.
     * @param weight      The item's weight in units.
     * @param riddle      The associated riddle (can be null if no riddle is present).
     */
    public Item(String name, String description, int weight, Riddle riddle) {
        this.name = name;                   // Set the item's name
        this.description = description;     // Set the item's description
        this.weight = weight;               // Set the item's weight
        this.riddle = riddle;               // Set the associated riddle, which may be null if no riddle is provided
    }

    /**
     * Returns the item's name.
     *
     * @return The name of the item.
     */
    public String getName() {
        return name;                        // Return the item's name
    }

    /**
     * Returns the item's description.
     *
     * @return The description of the item.
     */
    public String getDescription() {
        return description;                 // Return the item's description
    }

    /**
     * Returns the item's weight.
     *
     * @return The weight in units.
     */
    public int getWeight() {
        return weight;                      // Return the item's weight
    }

    /**
     * Returns the associated riddle.
     *
     * @return The riddle if associated, or null if there is no riddle.
     */
    public Riddle getRiddle() {
        return riddle;                      // Return the associated riddle or null if there is none
    }
}
