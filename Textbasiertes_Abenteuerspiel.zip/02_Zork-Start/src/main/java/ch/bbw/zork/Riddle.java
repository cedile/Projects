package ch.bbw.zork;

/**
 * Represents a riddle with a question and an answer.
 */
public class Riddle {
    private String question;    // Stores the riddle question text
    private String answer;      // Stores the correct answer to the riddle in lowercase

    /**
     * Creates a new riddle.
     *
     * @param question The riddle question.
     * @param answer   The correct answer to the riddle.
     */
    public Riddle(String question, String answer) {
        this.question = question;                 // Set the riddle question
        this.answer = answer.toLowerCase();       // Set the answer, converting it to lowercase for case-insensitive comparison
    }

    /**
     * Returns the riddle question.
     *
     * @return The question.
     */
    public String getQuestion() {
        return question;                          // Return the riddle question text
    }

    /**
     * Checks if the provided answer is correct.
     *
     * @param userAnswer The user's answer.
     * @return True if the answer is correct, false otherwise.
     */
    public boolean checkAnswer(String userAnswer) {
        // Compare the correct answer with the user's answer, converting the user's answer to lowercase for a case-insensitive check
        return this.answer.equals(userAnswer.toLowerCase());
    }
}
